Installation:
Klicken sie Auf die Anwendung "Fahrplan" und bereits wird die Software gestartet.

Deinstallation:
Da sich alles in dem Ordner befindet, m�ssen Sie nur den ganzen Ordner L�schen und bereits ist die Software deinstalliert.